import sys
import pandas as pd
from .topsis_102103043 import *
if __name__=="__main__":
    main()









