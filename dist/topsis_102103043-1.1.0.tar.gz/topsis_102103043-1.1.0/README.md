This package is implementation of topsis technique of multi-criteria decision analysis.
This package will accept three parameters:
1. data.csv //file which contains the models and parameters
2. string of weights metric separated by commas(,)
3. string of impacts (+/-) separated by commas(,)
// important
install pandas,sys and math libraries before installing this
//
You can install this package using following command
pip install topsis-102103043

